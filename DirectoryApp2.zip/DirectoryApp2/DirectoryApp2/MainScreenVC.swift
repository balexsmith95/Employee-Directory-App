//
//  MainScreenVC.swift
//  EmployeeDirectory
//
//  Created by user196870 on 5/15/21.
//

import UIKit

class MainScreenVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var employeeTableView: UITableView!
    
    var employees: [DirectoryModel] = []
    var url = "https://s3.amazonaws.com/sq-mobile-interview/employees.json"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Employee Directory"
        downloadJSON{
            self.employeeTableView.reloadData()
        }
        
        employeeTableView.delegate = self
        employeeTableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.employees.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = self.employees[indexPath.row].full_name.capitalized
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showDetails", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? DirectoryScreenVC {
            destination.employee = employees[(employeeTableView.indexPathForSelectedRow?.row)!]
        }
    }
    
    func downloadJSON(completed: @escaping () -> ()) {
        let url = URL(string: "https://s3.amazonaws.com/sq-mobile-interview/employees.json")!
    
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard error == nil else {
                print ("error: \(error!)")
                return
            }
            
            guard let data = data else {
                print("No data")
                return
            }
            
            guard let employeeData = try? JSONDecoder().decode([String: [DirectoryModel]].self, from: data) else {
                print ("Error: couldn't decode data into dictionary")
                return
            }
            let key = employeeData["employees"]!
            
            self.employees = key
            DispatchQueue.main.async {
                self.employeeTableView.reloadData()
            }
        }
        task.resume()
        
    }
    
}
