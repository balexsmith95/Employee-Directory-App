//
//  DirectoryScreenVC.swift
//  EmployeeDirectory
//
//  Created by user196870 on 5/15/21.
//

import UIKit

class DirectoryScreenVC: UIViewController {
    
    //declare outlets for employee view screen
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var teamLabel: UILabel!
    @IBOutlet weak var employeeTypeLabel: UILabel!
    @IBOutlet weak var bioLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    
    var employee: DirectoryModel?
    var typeFormatted: String = ""
    var formattedNumber: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameLabel.text = employee?.full_name
        teamLabel.text = employee?.team
        bioLabel.text = "Bio: " + employee!.biography
        emailLabel.text = "Email: " + employee!.email_address
        
        typeFormatted = decideEmployeeType(employee: employee!)
        employeeTypeLabel.text = typeFormatted
        
        formattedNumber = formatPhoneNumber(employee: employee!)
        phoneLabel.text = "Phone: " + formattedNumber
        
        let urlString = (employee?.photo_url_small)!
        let url = URL(string: urlString)
        profileImageView.downloaded(from: url!)
    }
    
    func decideEmployeeType(employee: DirectoryModel) -> String {
        let employee_type = employee.employee_type
        var typeFormatted: String
        
        switch employee_type {
        case "FULL_TIME":
            typeFormatted = "Full time employee"
        case "PART_TIME":
            typeFormatted = "Part time employee"
        default:
            typeFormatted = "something broke"
        }
        return typeFormatted
    }
    
    func formatPhoneNumber(employee: DirectoryModel) -> String {
        var formattedNumber = employee.phone_number
        
        formattedNumber.insert("(", at: formattedNumber.startIndex)
        formattedNumber.insert(")", at: formattedNumber.index(formattedNumber.startIndex, offsetBy: 4))
        formattedNumber.insert(" ", at: formattedNumber.index(formattedNumber.startIndex, offsetBy: 5))
        formattedNumber.insert("-", at: formattedNumber.index(formattedNumber.startIndex, offsetBy: 9))
        return formattedNumber
    }
    
}

extension UIImageView {
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}
