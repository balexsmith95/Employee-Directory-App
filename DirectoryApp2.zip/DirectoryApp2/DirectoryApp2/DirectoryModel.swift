//
//  DirectoryModel.swift
//  EmployeeDirectory
//
//  Created by user196870 on 5/15/21.
//

import Foundation

struct DirectoryModel:Decodable {
    let full_name: String
    let phone_number: String
    let email_address: String
    let biography: String
    let photo_url_small: String
    let photo_url_large: String
    let team: String
    let employee_type: String
    }

